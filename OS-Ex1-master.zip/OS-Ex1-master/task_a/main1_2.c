#include "hello_ariel.h"
#include <stdlib.h>

int main() {

    // int export_command = system("export LD_LIBRARY_PATH=.");
    // printf("export_command = %d\n", export_command);
    welcome("Tal");
    return 0;
}