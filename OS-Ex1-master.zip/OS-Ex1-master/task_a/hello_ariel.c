#include "hello_ariel.h"

void welcome(char *name) {
    printf("Welcome, %s\n", name);
}