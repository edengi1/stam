#include "hello_ariel.h"

int main() {

    welcome("Itay");
    
    return 0;
}