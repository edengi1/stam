#include <stdio.h>

void welcome(char *name);